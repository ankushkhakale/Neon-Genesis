// Title: Menu-Driven Program for Student Performance Analysis Using Arrays

// Problem Statement: Write a menu driven program using arrays to create a system to store
// and manage marks for a set of students in a class. 
//a. Use an array to store student marks for different subjects for a given class of students. 
//b. Implement functions to calculate the total marks, average marks, and the highest/lowest marks for each student. 
//c. Search for a specific student and display his marks and rank based on performance.
#include<iostream>
#include<string>
using namespace std;

class Student
{
    public:
    int no_of_students = 0;
    string arr[101][7] =
    {
        {"Student name", "Math", "Science", "English", "Marathi", "Hindi", "Total"}
    };

    Student(int x):no_of_students(x){}
    
    void input_marks()
    {
        int sum = 0;
        for(int i = 1;i <= no_of_students;i++)
        {
            cout<<"Enter name of the student = ";
            cin>>arr[i][0];
            cout<<"Enter marks for Math = ";
            cin>>arr[i][1];
            cout<<"Enter marks for Science = ";
            cin>>arr[i][2];
            cout<<"Enter marks for English = ";
            cin>>arr[i][3];
            cout<<"Enter marks for Marathi = ";
            cin>>arr[i][4];
            cout<<"Enter marks for Hindi = ";
            cin>>arr[i][5];
            sum = stoi(arr[i][1]) + stoi(arr[i][2]) + stoi(arr[i][3]) + stoi(arr[i][4]) + stoi(arr[i][5]);
            arr[i][6] = to_string(sum);
        }
    }

    void display()
    {
        for(int i = 0; i <= no_of_students;i++)
        {
            for(int j = 0;j < 7;j++)
                cout<<arr[i][j]<<" ";
            cout<<endl;
        }
        string name1, name2;
        int highest = stoi(arr[1][6]), lowest = stoi(arr[1][6]);
        cout<<"Highest and lowest = ";
        for(int i = 1;i <= no_of_students;i++)
        {
            if(highest < stoi(arr[i][6]))
            {
                highest = stoi(arr[i][6]);
                name1 = arr[i][0];
            }
            if(lowest > stoi(arr[i][6]))
            {
                lowest = stoi(arr[i][6]);
                name2 = arr[i][0];
            }
        }
        cout<<"Student with highest percentage = "<<name1;
        cout<<"\nStudent with lowest percentage = "<<name2;
    }

    void calculations(string name)
    {
        for(int i = 1;i <= no_of_students;i++)
        {
            if(name == arr[i][0])
            {
                int rank = 1;
                cout<<"Student data : ";
                for(int j = 0;j < 7;j++)
                    cout<<arr[i][j]<<"\t";
                int totalmks = stoi(arr[i][6]);
                double percentage = (totalmks / 500.0) * 100;
                cout<<"Percentage = "<<percentage<<endl;
                for(int j = 1;j < no_of_students;j++)
                {
                    if(stoi(arr[j][6]) > totalmks)
                    {
                        rank++;
                    }
                }
                cout<<"Rank = "<<rank;
            }
        }
    }
};
int main()
{
    int x;
    cout << "Enter number of students in class (max 100) = ";
    cin >> x;

    if (x > 100)
    {
        cout << "Student limit exceeded!";
        return 0;
    }

    Student s(x);
    int iterator;

    do
    {
        cout << "\n\n--- Student Menu ---\n";
        cout << "1. Input student data\n";
        cout << "2. Display all student data\n";
        cout << "3. Search and show a student's details\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> iterator;

        switch (iterator)
        {
            case 1:
                s.input_marks();
                break;
            case 2:
                s.display();
                break;
            case 3:
            {
                cout << "Enter student name: ";
                string nm;
                cin >> nm;
                s.calculations(nm);
                break;
            }
            case 0:
                cout << "Exiting program...\n";
                break;
            default:
                cout << "Invalid choice! Try again.\n";
        }

    } while (iterator != 0);

    return 0;
}

//Code algorithm
/*
    first create a method for taking input for number of students, let's keep the subject 5
    (Math, science, marathi, hindi, english), we will use a 2d array, 6 columns for 5 subjects
    and student_name column, and below them will be the student marks with one extra row, 
    basically, 
    "string arrayofstudents[no_of_students+1][6]"
    the first column and row will be kept static and only the other will change...

    also lets take one more column for total
*/
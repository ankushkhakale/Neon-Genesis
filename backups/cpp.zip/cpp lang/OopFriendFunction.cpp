#include<iostream>
using namespace std;

class Complex
{
    public:
    int r, i;
    Complex():r(0), i(0){}
    Complex(int r, int i):r(r),i(i){}
    Complex operator+(Complex c)
    {
        Complex temp;
        temp.r = r + c.r;
        temp.i = i + c.i;
        return temp;
    } 
    
    Complex operator*(Complex c)
    {
        Complex temp;   
        temp.r = r * c.r;
        temp.i = i * c.i;
        return temp;
    }

    void printComplexNo()
    {
        cout<<r<<" + "<<i<<"i"<<endl;
    }
};

int main()
{
    Complex c1(3,5), c2(5, 3);
    // Complex c3 = c1.operator+(c2);
    Complex c3 = c1 + c2;
    c3.printComplexNo();
    c3 = c1 * c2;
    c3.printComplexNo();
    return 0;
}
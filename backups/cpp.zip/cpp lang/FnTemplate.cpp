#include <iostream>
using namespace std;

template <class T>
void calculateBill(string name, T units, T rate) {
    T total = units * rate;
    cout << "\nConsumer: " << name;
    cout << "\nUnits: " << units << "  Rate: " << rate;
    cout << "\nTotal Bill: " << total << endl;
}

int main() {
    calculateBill<float>("Mohit", 350.5, 6.75);
    calculateBill<int>("Ravi", 200, 7);
}

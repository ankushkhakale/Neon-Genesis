#include<iostream>
#include<fstream>//file stream
using namespace std;

int main()
{
    ofstream of;
    of.open("first.txt");//opens the file
    of<<"File Handling in c++";//Writes data in file...(fist.txt)
    cout<<"file created succesfully";//Displays this message on console
    of.close();//closes the file
    return 0;
}
#include <iostream>
#include <string>
using namespace std;


class Account {
protected:
    string accountNumber;
    int pin;
    double balance;

public:
    Account(string accNum = "0000", int p = 1234, double bal = 0.0)
        : accountNumber(accNum), pin(p), balance(bal) {}

    bool verifyPIN(int enteredPIN) {
        return enteredPIN == pin;
    }

    double getBalance() const {
        return balance;
    }

    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            cout << "Successfully deposited $" << amount << endl;
        } else {
            cout << "Invalid deposit amount!" << endl;
        }
    }

    bool withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            cout << "Successfully withdrew $" << amount << endl;
            return true;
        } else {
            cout << "Insufficient balance or invalid amount!" << endl;
            return false;
        }
    }
};


class ATM : public Account {
public:
    ATM(string accNum, int p, double bal) : Account(accNum, p, bal) {}

    void menu() {
        int choice;
        do {
            cout << "\n==== ATM Menu ====\n";
            cout << "1. Check Balance\n";
            cout << "2. Deposit\n";
            cout << "3. Withdraw\n";
            cout << "4. Exit\n";
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice) {
                case 1:
                    cout << "Your balance is: $" << getBalance() << endl;
                    break;
                case 2: {
                    double dep;
                    cout << "Enter amount to deposit: ";
                    cin >> dep;
                    deposit(dep);
                    break;
                }
                case 3: {
                    double wd;
                    cout << "Enter amount to withdraw: ";
                    cin >> wd;
                    withdraw(wd);
                    break;
                }
                case 4:
                    cout << "Thank you for using the ATM!" << endl;
                    break;
                default:
                    cout << "Invalid choice!" << endl;
            }
        } while (choice != 4);
    }
};


int main() {
    string accNum = "123456";
    int pin = 4321;

    ATM atm(accNum, pin, 1000.0); 

    cout << "=== Welcome to the ATM ===" << endl;
    int enteredPIN;
    cout << "Enter your 4-digit PIN: ";
    cin >> enteredPIN;

    if (atm.verifyPIN(enteredPIN)) {
        cout << "PIN verified successfully!\n";
        atm.menu();
    } else {
        cout << "Incorrect PIN! Access denied.\n";
    }

    return 0;
}
#include<iostream.h>
#include<string.h>
using namespace std;

int main(){
    string name;
    int n;
    cout<<"enter the value of n = ";
    cin>>n;
    cin.ignore();
    getline(cin, name);
        return 0;
}
#include<iostream>
#include<string>
using namespace std;

class student
{
    public:
    int x;
    void accept()
    {
        cout<<"enter student roll number = ";
        cin>>x;
    }
};

class student2 : public student 
{
    public:
    string name;
    void accept2()
    {
        accept();
        cout<<"\nenter student name = ";
        cin.ignore();
        getline(cin,name);
    }
};

class marks
{
    public:
    void totalmarks()
    {
        cout<<"\nstudent marks = "<<98<<"%";
    }
};

class hybrid : public student2,public marks
{
    public:
    void show()
    {
        accept2();
        cout<<"\nstudent name = "<<name;
        cout<<"\nstudent roll number = "<<x;
        totalmarks();
    }

};

int main()
{
    hybrid h;
    h.show();
    return 0;
}
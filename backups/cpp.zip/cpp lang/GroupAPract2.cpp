// Title: String Operations without Library Functions

// Problem Statement: Write a menu driven program to perform String Operations without
// Library Functions.
// a. Calculate Length of string
// b. Concatenate two strings
// c. Reverse a String
// d. Check whether given string is Palindrome or not
#include<iostream>
#include<string>
using namespace std;

int sizeOfString(string str)
{
    int size = 0;
    for(int i = 0;;i++)
    {
        if(str[i] != '\0')
        {
            size = size + 1;   
        }
        else break;
    }
    return size;
}

string reversed(string str)
{
    string rstring = "";
    int size = sizeOfString(str);
    for(int i = size - 1;i >= 0;i--)
    {
        rstring = rstring + str[i];
    }
    return rstring;
}

int main()
{
    int num;
    
    string str, str1, str2, reversedstring, concatenated;
    int size;
    do
    {
        cout << "\nEnter choice (0-4): ";
        cin >> num;
        cin.ignore();
        
        switch(num)
        {
            case 0:
                num = 0;
            break;
            
            case 1:
                cout<<"Enter a string = ";
                getline(cin, str);
                size = sizeOfString(str);
                cout<<"\nString length = "<<size;
            break;
            
            case 2:
                cout<<"\nEnter string one = ";
                cin>>str1;
                cout<<"Enter string two = ";
                cin>>str2;
                concatenated = str1 + str2;
                cout<<"Concatenated string = "<<concatenated;
            break;
            
            case 3:
                cout<<"Enter a string = ";
                getline(cin, str);
                reversedstring = reversed(str);
                cout<<reversedstring;
            break;
            
            case 4:
                cout<<"Enter a string = ";
                getline(cin, str);
                size = sizeOfString(str);
                int ctr = 0;
                for(int i = 0;i < size/2; i++)
                {
                    if(tolower(str[i]) != tolower(str[size - i - 1]))
                    {
                        ctr = 1;
                        break;
                    }
                }
                if(ctr == 1)
                    cout<<"\nString is not palindrome";
                else
                    cout<<"\nString is palindrome";
            break;
        }
    }while(num!=0);
    

    return 0;
}
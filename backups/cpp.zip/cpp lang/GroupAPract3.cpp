// Title: Set Operations using One Dimensional Arrays

// Problem Statement: Write a menu-driven program that allows the user to perform the
// following set operations using one dimensional array:
// a. Union
// b. Intersection
// c. Difference
// d. Subset

#include<iostream>
using namespace std;

int main()
{
    //well, lets see just add the elements of A in a variable called C(use for union) and then add the elements of the B in C
    // but first check if the elements in B exist in a or not...
    int A[50],B[50],n1,n2;
    cout<<"Enter number of elements in set A = ";
    cin>>n1;
    for(int i = 0;i < n1;i++)
    {
        cout<<"\nEnter a number = ";
        cin>>A[i];
    }
    cout<<"Enter number of elements in set B = ";
    cin>>n2;

    for(int i = 0;i < n2;i++)
    {
        cout<<"\nEnter a number = ";
        cin>>B[i];
    }
    
    int C[100], k = 0;
    for(int i = 0;i < n1;i++)
        C[k++] = A[i];

    for(int i = 0;i < n2;i++)
    {
        bool exists = false;
        for(int j = 0;j < n1;j++)
        {
            if(B[i] == A[j])
            {
                exists = true;
            }
        }
        if(!exists)
        {
            C[k++] = B[i];
        }
    }
    for(int i = 0;i < k;i++)
    {
        cout<<C[i];
    }
    return 0;
}
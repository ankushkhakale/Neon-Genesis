#include<iostream>
using namespace std;

class base
{
    public:
    int var_base;
    void Fun_Base(int a)
    {
        var_base = a;
        cout<<"This is base class and var_base = "<<var_base<<endl;
    }
};

class derived : public base 
{
    public:
    int var_derived;
    void Fun_Base(int b)
    {
        var_derived = b;
        cout<<"This is derived class and var_derived = "<<var_derived<<endl;
    }
};

int main()
{
    base obj;
    base *base_class_pointer = &obj;
    base_class_pointer->Fun_Base(30);
    derived obj2;
    base_class_pointer = &obj2;
    base_class_pointer->Fun_Base(50);   
    derived *derived_class_pointer = &obj2;
    derived_class_pointer->Fun_Base(30);
    return 0;
}
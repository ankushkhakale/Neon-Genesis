#include<iostream.h>
using namespace std;

int main()
{
    //reference variables : what this does is that if you change the value of x the value of y will e aslo changed parralely
    //this is called as reference variable because there are two variables which will have same value throught the program
    int x = 45;
    int &y = x;

    cout<<"the value of x is = "<<x;
    cout<<"\nthe value of y is = "<<y;

    x = 5;

    cout<<"\nupdated value of x = "<<x;
    cout<<"\nupdated value of y = "<<y;

    y = 6;

    cout<<"\nnext value of x is = "<<x;
    cout<<"\nnext value of y is = "<<y;
        return 0;
}
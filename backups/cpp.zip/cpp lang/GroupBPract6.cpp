// Title: Polynomial Addition using Linked List

// Problem Statement: Represent two polynomials using linked lists (each node contains
// coefficient and exponent). Write code to add the polynomials and display the result.
#include <iostream>
using namespace std;

struct Node {
    int coeff;
    int pow;
    Node* next;
};

int main() {
    // ----- Polynomial 1: 5x^2 + 4x^1 + 2x^0 -----
    Node *p1 = new Node{5, 2, NULL};
    p1->next = new Node{4, 1, NULL};
    p1->next->next = new Node{2, 0, NULL};

    // ----- Polynomial 2: 3x^2 + 5x^1 + 5x^0 -----
    Node *p2 = new Node{3, 2, NULL};
    p2->next = new Node{5, 1, NULL};
    p2->next->next = new Node{5, 0, NULL};

    // ----- Result Polynomial -----
    Node *sum = new Node{p1->coeff + p2->coeff, p1->pow, NULL};
    sum->next = new Node{p1->next->coeff + p2->next->coeff, p1->next->pow, NULL};
    sum->next->next = new Node{p1->next->next->coeff + p2->next->next->coeff, p1->next->next->pow, NULL};

    // ----- Display -----
    cout << "First Polynomial: "
         << p1->coeff << "x^" << p1->pow << " + "
         << p1->next->coeff << "x^" << p1->next->pow << " + "
         << p1->next->next->coeff << "x^" << p1->next->next->pow << endl;

    cout << "Second Polynomial: "
         << p2->coeff << "x^" << p2->pow << " + "
         << p2->next->coeff << "x^" << p2->next->pow << " + "
         << p2->next->next->coeff << "x^" << p2->next->next->pow << endl;

    cout << "Resultant Polynomial: "
         << sum->coeff << "x^" << sum->pow << " + "
         << sum->next->coeff << "x^" << sum->next->pow << " + "
         << sum->next->next->coeff << "x^" << sum->next->next->pow << endl;

    return 0;
}

#include<iostream>
#include<fstream>
#include<string>
using namespace std;

int main()
{
    ifstream iff;
    string str;
    iff.open("first.txt");/*We have opened the file 'first.txt'
     using iff as object of ifstream, using open funtion  */ 
    /* this getline funtion copies the data from iff(objext of ifstream)
    the 'first.txt' file to the str   */
    while(getline(iff,str))    
    {
        cout<<str;
    }
    iff.close();//Closes the file
    return 0;
}
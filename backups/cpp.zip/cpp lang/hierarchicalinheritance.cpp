#include <iostream.h>
using namespace std;

class base
{
public:
    static int x;
    void basee()
    {
        cout << "\nbase class " << x;
        x++;
    }
};

class DerivedA : public base
{
public:
    void DA()
    {
        cout << "\nderived class A";
    }
};

class DerivedB : public base
{
public:
    void DB()
    {
        cout << "\nDerived class B";
    }
};

class DerivedA1 : public DerivedA
{
public:
    void DA1()
    {
        basee();
        DA();
        cout << "\nderived class a1";
    }
};

class DerivedB1 : public DerivedB
{
public:
    void DB1()
    {
        basee();
        DB();
        cout << "\nDerived class b1";
    }
};

int base :: x = 1;

int main()
{
    cout<<endl<<endl<<endl;
    cout<<"note there are not two base class only one you will see base class one and two to understand that base class  is called two times\n\n";
    DerivedA1 a1;
    a1.DA1();
    cout<<"\n\n\n";
    DerivedB1 b1;
    b1.DB1();
    cout<<"\n\n\n";
    return 0;
}
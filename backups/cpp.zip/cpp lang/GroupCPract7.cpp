// Title: Stack Implementation Using Arrays

// Problem Statement: Write a menu-driven program to implement a stack as an ADT
// using arrays. Include operations such as push, pop, peek (top element), and display.
// Ensure overflow and underflow conditions are handled. Use this ADT for decimal to
// binary conversion using stack.
#include <iostream>
using namespace std;

#define SIZE 10

class Stack {
    int arr[SIZE];
    int top;

public:
    Stack() { top = -1; }

    void push(int x) {
        if (top == SIZE - 1)
            cout << "Overflow! Stack full.\n";
        else
            arr[++top] = x;
    }

    void pop() {
        if (top == -1)
            cout << "Underflow! Stack empty.\n";
        else
            top--;
    }

    void peek() {
        if (top == -1)
            cout << "Stack is empty.\n";
        else
            cout << "Top element: " << arr[top] << endl;
    }

    void display() {
        if (top == -1)
            cout << "Stack is empty.\n";
        else {
            cout << "Stack elements: ";
            for (int i = top; i >= 0; i--)
                cout << arr[i] << " ";
            cout << endl;
        }
    }

    void decimalToBinary(int n) {
        top = -1; // clear stack
        while (n > 0) {
            push(n % 2);
            n = n / 2;
        }
        cout << "Binary: ";
        while (top != -1) {
            cout << arr[top];
            top--;
        }
        cout << endl;
    }
};

int main() {
    Stack s;
    int choice, val;

    do {
        cout << "\n1.Push  2.Pop  3.Peek  4.Display  5.Decimal→Binary  6.Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            cout << "Enter value: ";
            cin >> val;
            s.push(val);
        }
        else if (choice == 2)
            s.pop();
        else if (choice == 3)
            s.peek();
        else if (choice == 4)
            s.display();
        else if (choice == 5) {
            cout << "Enter decimal number: ";
            cin >> val;
            s.decimalToBinary(val);
        }
        else if (choice == 6)
            cout << "Exiting...\n";
        else
            cout << "Invalid choice!\n";

    } while (choice != 6);

    return 0;
}

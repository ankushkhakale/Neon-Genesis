#include<iostream>
using namespace std;

class complex
{
    int a,b;
    public:
    void cmplx(int n1,int n2)
    {
        a = n1;
        b = n2;
    }
    void display()
    {
        cout<<"\nSubstraction of complex number = "<<a<<" + "<<b<<"i"<<endl;
    }
    friend complex subcomplex(complex o1,complex o2);
};

    complex subcomplex(complex o1,complex o2)
    {
        complex o3;
        o3.cmplx((o1.a+o2.a),(o1.b+o2.b));
        return o3;
    }

    int main()
    {
        int a,b,c,d;
        
        cout<<"\nEnter a = ";
        cin>>a;
        cout<<"\nEnter b = ";
        cin>>b;
        cout<<"\nEnter c = ";
        cin>>c;
        cout<<"\nEnter d = ";
        cin>>d;

        complex c1,c2;
        c1.cmplx(a,b);
        c2.cmplx(c,d);
        complex sub;
        sub = subcomplex(c1,c2);
        cout<<"\n(a+c)'+'(b+d)";
        sub.display();
        return 0;
    }
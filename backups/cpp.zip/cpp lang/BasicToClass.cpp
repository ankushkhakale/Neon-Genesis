#include<iostream>
using namespace std;

class Complex
{   int real;
    public:
    Complex(int x):real(x){}
};

int main()
{
    int x = 5;
    Complex c = x;
    return 0;
}
#include<iostream>
using namespace std;

int main()
{
    int x,y,c,z;
    cout<<"enter 1 for addition, 2 for division, 3 to caculate percentage, 4 for sustraction, 5 for multiplication = ";
    cin>>z;
    if(z == 1 ||z == 2 || z == 4 || z == 5)
    {
        cout<<"Enter x = ";
        cin>>x;
        cout<<"Enter y = ";
        cin>>y;
    }
    if(z == 1 && z < 6 && z > 0)
    {
        cout<<"Addition = "<<x + y;
    }
    else if(z == 2 && z < 6 && z > 0)
    {
        cout<<"Division = "<<x/y;
    }

    else if(z == 3 && z < 6 && z > 0)
    {
        float total;
        float totalvalue;
        cout<<"Enter parts(marks acheived) = ";
        cin>>total;
        cout<<"Enter whole(marks achievable) = ";
        cin>>totalvalue;
        cout<<"percentage = "<<(total/totalvalue)*100<<"%";
    }

    else if(z == 4 && z < 5 && z > 0)
    {
        cout<<"Substraction = "<<x - y;
    }

    else if(z == 5 && z < 5 && z > 0)
    {
        cout<<"Mutiplication = "<<x * y;
    }

    else
    {
        cout<<"You have not chossen any option";
    }
    return 0;
}
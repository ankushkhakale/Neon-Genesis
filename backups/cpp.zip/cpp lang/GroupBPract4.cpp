// Title: Singly Linked List Operations

// Problem Statement:
// Write a menu-driven program to implement a singly linked list that allows the user to
// perform basic operations such as insertion (at beginning, end, and specific position),
// deletion, display, and count the number of nodes.
#include<iostream>
using namespace std;

int size = 1;

struct Node
{
    int data;
    Node *next;
};



void display(Node *head)
{   
    int i = 1;
    while(head!=NULL)
    {
        
        cout<<"\nNode "<<i<<" = "<<head->data;
        head = head->next;
        i++;
    }
}

void inserAtBeginning(Node*& head)
{
    int x;
    cout<<"\nEnter the value you want to insert at the beginning = ";
    cin>>x;
    Node *newNode = new Node;
    newNode->data = x;
    newNode->next = head;
    head = newNode;

}

void insertAtEnd(Node*& head)
{
    Node* temp = head;
    int x;
    cout<<"\nEnter the value you want to insert at the end = ";
    cin>>x;
    while(temp->next != NULL)
    {
        temp = temp->next;
    }
    Node *newNode = new Node;
    newNode -> data = x;
    newNode -> next = NULL;
    temp->next = newNode;
}

void insertAtPosition(Node*& head)
{
    Node* temp = head;
    Node* temp2 = head;
    while(temp->next != NULL)
    {
        temp = temp->next;
        size++;
    }
    temp = head;
    temp2 = head;
    cout<<"\nSize of LL = "<<size;
    cout<<"\nEnter position = ";
    int pos;
    cin>>pos;
    for(int i = 1;i < pos;i++)
    {
        temp = temp->next;
    }
    for (int i = 1; i < pos - 1; i++)
    {
        temp2 = temp2->next;
    }
    int x;
    cout<<"\nEnter the value you want to insert = ";
    cin>>x;
    Node *newNode = new Node;
    newNode->data = x;
    newNode->next = temp;
    temp2 -> next = newNode;
}

int main()
{
    Node *head = NULL;
    Node *newNode;
    Node *temp;
    int x,y;
    do
    {   
        newNode = new Node;
        cout<<"Enter a value = ";
        cin>>y;
        newNode->data = y;
        newNode->next = NULL;

        if(head == NULL)
        {
            head = newNode;
            temp = head;
        }
        else
        {
            temp->next = newNode;
            temp = newNode;
        }
        

        cout<<"\nTo continue enter 1 or enter 0 to exit = ";
        cin>>x;
    }while(x == 1);

    display(head);
    inserAtBeginning(head);
    display(head);
    insertAtEnd(head);
    display(head);
    insertAtPosition(head);
    display(head);
    return 0;
}
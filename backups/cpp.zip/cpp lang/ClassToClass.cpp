#include <iostream>
using namespace std;

class CaloriesTracker; // forward declaration

class StepsTracker {
    int steps;
public:
    StepsTracker(int s = 0) { steps = s; }
    int getSteps() { return steps; }
    void show() { cout << "Steps = " << steps << endl; }

    // class-to-class conversion: Steps → Calories
    operator CaloriesTracker();
};

class CaloriesTracker {
    float calories;
public:
    CaloriesTracker(float c = 0) { calories = c; }
    void show() { cout << "Calories = " << calories << endl; }

    friend class StepsTracker;
};

// conversion definition (after CaloriesTracker is known)
StepsTracker::operator CaloriesTracker() {
    float cal = steps * 0.04;  // conversion logic
    return CaloriesTracker(cal);
}

int main() {
    StepsTracker s1(5000);
    s1.show();

    CaloriesTracker c1;
    c1 = s1;   // Steps → Calories
    c1.show();

    return 0;
}

#include<iostream>
using namespace std;

class Complex
{   int real;
    public:
    Complex(int x):real(x){}
    operator int()
    {
        return real;
    }
};

int main()
{
    int x = 5;
    Complex c = x;
    int y = c;
    cout<<y;
    return 0;
}
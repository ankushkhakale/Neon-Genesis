#include<iostream.h>
using namespace std;

class overload
{
    //sum of float and int
    public:
    void sum(int,int);
    void sum(float,float);
};

void overload :: sum(int a,int b)
{
    cout<<"\nsum of the two number(int) = "<<a + b;
}

void overload :: sum(float a,float b)
{
    cout<<"\nsum of two floats = "<<a + b;
}

int main()
{
    overload o;
    o.sum(2,3);
    o.sum(2.3f,4.3f);
    return 0;
}
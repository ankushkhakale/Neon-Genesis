#include <iostream>
#include <string>
#include <unistd.h>
using namespace std;

class Security
{
public:
    int x,y = 0;
    int age;
    string id = "9130009794";
    string password, name, id2;

    void auth()
    {
        password = "1";
        cout << "To secure your account, create a password..." << endl;
        while (password.size() < 4)
        {
            cout << "Enter a password: ";
            getline(cin, password);

            if (password.size() < 4)
            {
                cout << "Password should be at least 4 characters long." << endl;
            }
            else
            {
                cout << "Password is set." << endl;
            }
        }
    }

    void inpdata()
    {
        cout << "Enter your name: ";
        getline(cin, name);
        cout << "Enter your age: ";
        cin >> age;

        if (age >= 18)
        {
            x = 0;
            cout << "Eligible to use this software." << endl;
            while (x < 5)
            {
                cout << "Enter your voter id: ";
                cin.ignore();
                getline(cin, id2);
                if (id == id2)
                {
                    y = 1;
                    break;
                }
                else
                {
                    cout << "Wrong id. Please enter the correct id." << endl;
                    x++;
                    if (x == 5)
                    {
                        cout << "Terminated." << endl;
                        cout << "Stopping for 30 seconds..." << endl;
                        sleep(30);
                        cout << "If you want to try entering id again, enter 0. Enter any other number to exit: ";
                        cin >> x;
                        if (x == 0)
                        {
                            x = 0;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }
        }
        else
        {
            cout << "Not eligible to use this software." << endl;
        }
    }
};

class Function : public Security
{
public:
    void accept()
    {
        auth();
        inpdata();
    }

    void display()
    {
        if (y == 1)
        {
            cout << "\nVoter Details" << endl;
            cout << "Name: " << name << endl;
            cout << "Voter id: " << id << endl;
            cout << "Aadhar number: 6809-9874-4833" << endl;
            cout << "Mother's name: Chetana Nitin Bhole" << endl;
            cout << "Father's name: Nitin Vasudeo Bhole" << endl;
            cout << "Phone number: 7507209119" << endl;
            cout << "Education: Computer Engineer" << endl;
        }
        else if(y == 0 && age >=18)
        {
            cout <<"\nContact your nearest Mahanagarpalika office to recover voter's id." << endl;
        }
        if(age <=18)
        {
            cout<<"\nAge error";
        }
        
    }
};

int main()
{
    Function f;
    f.accept();
    f.display();
    return 0;
}

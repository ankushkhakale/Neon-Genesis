#include<iostream.h>
#include<string.h>
using namespace std;

class Employee{
    private:
        int salary;
        int bonus;
        char name[20];
        public:
        int empno;
        int id;
    void input(int id,int sal,int bon,char nm[],int empno);
    void output();
};

void Employee :: input(int id,int sal,int bon,char nm[],int empno){
    for(int i = 0;i < empno;i++){
        cout<<"\nemployee "<<i+1<<" = ";
        cout<<"\nenter id = ";
        cin>>id;
        cout<<"enter employee name = ";
        cin>>nm;
        cout<<"enter salary = ";
        cin>>sal;
        cout<<"enter bonus = ";
        cin>>bon;
    }
    strcpy(name,nm);
    salary = sal;
    bonus = bon;
}

void Employee :: output(){
    cout<<"\nName of employee = "<<name;
    cout<<"\nemployee id = "<<id;
    cout<<"\nsalary = "<<salary;
    cout<<"\nenter diwali bonus = "<<bonus;
}

int main(){
    int empno;
    cout<<"enter the number of employees in your office = ";
    cin>>empno;
    Employee emp;

        int id1;
        char nm[20];
        int bon;
        int sal;
        emp.input(id1,sal,bon,nm,empno);   
        emp.output();
    
    return 0;
}
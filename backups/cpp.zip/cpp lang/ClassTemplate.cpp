#include <iostream>
using namespace std;

template <class T>
class GroceryCalculator {
    string item;
    T qty, price;
public:
    void get() {
        cout << "Enter item name: "; cin >> item;
        cout << "Enter quantity: "; cin >> qty;
        cout << "Enter price per unit: "; cin >> price;
    }
    void show() {
        cout << item << " | Qty: " << qty
             << " | Rate: " << price
             << " | Total: " << qty * price << endl;
    }
};

int main() {
    GroceryCalculator<int> g1;
    GroceryCalculator<float> g2;
    g1.get(); g1.show();
    g2.get(); g2.show();
}

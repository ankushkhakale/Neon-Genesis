#include <iostream>
using namespace std;

class Shape {
public:
    virtual void draw() { cout << "Drawing Shape\n"; }
};

class Circle : public Shape {
public:
    void draw() { cout << "Drawing Circle\n"; }
};

class Triangle : public Shape {
public:
    void draw() { cout << "Drawing Triangle\n"; }
};

class Square : public Shape {
public:
    void draw() { cout << "Drawing Square\n"; }
};

int main() {
    Shape *s;
    Circle c; Triangle t; Square sq;

    s = &c; s->draw();
    s = &t; s->draw();
    s = &sq; s->draw();
}

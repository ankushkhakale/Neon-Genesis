// Title: Circular Linked List-Based Token Management in Service Centers

// Problem Statement: Implement a token management system for a service center using a
// circular linked list. Each token represents a customer with Token Number, Customer
// Name, Service Type. The system should provide the following functionalities: a. Generate
// a new token (enqueue) b. Serve the next customer (dequeue from front) c. Display all
// waiting tokens d. Rotate through tokens cyclically e. Count remaining tokens in the queue.
#include<iostream>
using namespace std;

struct Node 
{
    int tokenNo;
    string customerName;
    string serviceType;
    Node* next;
};

Node* front = NULL;
Node* rear = NULL;

// Function to generate (enqueue) new token
void generateToken() 
{
    Node* newNode = new Node;
    cout << "\nEnter Token Number: ";
    cin >> newNode->tokenNo;
    cout << "Enter Customer Name: ";
    cin >> newNode->customerName;
    cout << "Enter Service Type: ";
    cin >> newNode->serviceType;
    newNode->next = NULL;

    if (front == NULL) {
        front = rear = newNode;
        rear->next = front; // make it circular
    } else {
        rear->next = newNode;
        rear = newNode;
        rear->next = front; // link last node back to first
    }

    cout << "\nToken generated successfully!\n";
}

// Function to serve (dequeue) next customer
void serveNext() 
{
    if (front == NULL) {
        cout << "\nNo tokens to serve!\n";
        return;
    }

    cout << "\nServing Token No: " << front->tokenNo 
         << " | Name: " << front->customerName
         << " | Service: " << front->serviceType << endl;

    Node* temp = front;

    // Only one node
    if (front == rear) {
        front = rear = NULL;
    } else {
        front = front->next;
        rear->next = front; // maintain circular connection
    }

    delete temp;
    cout << "Customer served successfully!\n";
}

// Function to display all waiting tokens
void displayTokens() {
    if (front == NULL) {
        cout << "\nNo waiting tokens!\n";
        return;
    }

    Node* temp = front;
    cout << "\n--- Waiting Tokens ---\n";
    do {
        cout << "Token No: " << temp->tokenNo 
             << " | Name: " << temp->customerName
             << " | Service: " << temp->serviceType << endl;
        temp = temp->next;
    } while (temp != front);
}

// Function to rotate tokens (move to next cyclically)
void rotateTokens() {
    if (front == NULL) {
        cout << "\nNo tokens to rotate!\n";
        return;
    }

    front = front->next;
    rear = rear->next;
    cout << "\nTokens rotated successfully!\n";
}

// Function to count remaining tokens
void countTokens() {
    if (front == NULL) {
        cout << "\nNo tokens in the queue!\n";
        return;
    }

    int count = 0;
    Node* temp = front;
    do {
        count++;
        temp = temp->next;
    } while (temp != front);

    cout << "\nRemaining Tokens: " << count << endl;
}

int main() {
    int choice;
    do {
        cout << "\n--- Service Center Token System ---";
        cout << "\n1. Generate New Token";
        cout << "\n2. Serve Next Customer";
        cout << "\n3. Display All Tokens";
        cout << "\n4. Rotate Tokens";
        cout << "\n5. Count Remaining Tokens";
        cout << "\n6. Exit";
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: generateToken(); break;
            case 2: serveNext(); break;
            case 3: displayTokens(); break;
            case 4: rotateTokens(); break;
            case 5: countTokens(); break;
            case 6: cout << "\nExiting program...\n"; break;
            default: cout << "\nInvalid choice!\n";
        }

    } while (choice != 6);

    return 0;
}

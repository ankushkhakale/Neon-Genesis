#include<iostream>
#include<fstream>
using namespace std;
//Question : Write a cpp program to copy content of one file into another

int main()
{
    ifstream iff;
    ofstream of;
    char s;
    iff.open("first.txt");
    of.open("second.txt");
    //Here the get() funtion makes accessible one-one character from the file 'first.txt' and as the
    //'second.txt' file is open using the output stream which only writes the string
    //values in the file, and the put funtion is used, this put funtion is putting every
    //single character of the 'first.txt' file to 'second.txt' file."it is more like read and put"
    while(!of.eof())
    {
        iff.get(s);
        of.put(s);
    }
    cout<<"file opened successfully"; 
    iff.close();
     of.close(); 
    return 0;
}
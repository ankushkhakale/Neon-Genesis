#include<iostream.h>

using namespace std;

class area{
    public:
    int area1;
    int area2;

area(int side){
    area1 = side*side;
}
area(float r){
    area2 = 3.145*r*r;
}
void showc(){
    cout<<"\narea of circle = "<<area2;
}
void shows(){
    cout<<"\narea of square = "<<area1;
}

};

int main(){
    float r;
    int side;
    cout<<"enter the radius of the circle = ";
    cin>>r;
    cout<<"enter the side of the square = ";
    cin>>side;
    area circle(r);
    area square(side);    
    circle.showc();
    square.shows();
    return 0;
}
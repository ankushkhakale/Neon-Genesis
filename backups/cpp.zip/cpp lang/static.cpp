#include <iostream.h>
using namespace std;

class temp
{
    static int count;
    public:
    static void fun()
    {
        cout<<"count = "<<count<<endl;
        count ++;
    }
};
int temp :: count;
int main()
{
    temp a,b,c,d;
    a.fun();
    b.fun();
    c.fun();
    d.fun();
    return 0;
}

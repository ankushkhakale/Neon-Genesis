#include<iostream.h>
using namespace std;

class complex{
    int a;
    int b;
    public:
    complex();
    void caller();
};

complex :: complex(){
    a = 1;
    b = 1;
    cout<<"hello world !";
}

void complex :: caller(){
    cout<<a+b;
}

int main(){
    complex c;
    c.caller();
    return 0;
}
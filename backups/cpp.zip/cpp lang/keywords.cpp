#include <iostream.h>
using namespace std;

class thisop
{
    public:
    int a,b;
    thisop(int a, int b)
    {
        this->a = a;
        this->b = b;
    }
    void show(void);
};

void thisop :: show(void) {
    cout<<a<<endl<<b;
}

int main()
{
    int n = 1;
    int m = 0;
    // and operator
    if (n == 1 and m == 0)
    {
        bool hello = true;
        cout << hello;
    }
    cout<<endl;

    // this-> operator
    thisop t(7,8);
    t.show();

    return 0;
}

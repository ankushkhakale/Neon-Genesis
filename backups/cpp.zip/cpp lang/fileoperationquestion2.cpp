#include<iostream>
#include<fstream>
using namespace std;
//Question : Write a c++ program to count number of spaces in a file
int main()
{
    char ch;
    ifstream iff;
    int cnt = 0;
    iff.open("first.txt");
    //[EOF (end of file)] This loop will run until the end of 
    //operator does not come
    while(!iff.eof())
    {
        iff.get(ch);
        if(ch == ' ')//Note:This is equal to equal to operator
        {
            cnt++;
        }
    }
    cout<<"\nNo. of spaces = "<<cnt;
    iff.close();
    return 0;
}
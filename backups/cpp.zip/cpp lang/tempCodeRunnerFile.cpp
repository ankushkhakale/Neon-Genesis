String
// d. Check whether
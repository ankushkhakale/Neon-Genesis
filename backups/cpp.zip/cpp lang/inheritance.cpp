#include<iostream.h>
#include<string.h>

using namespace std;

class student{
  
    public:    
    int m1,m2,id;
    string nm;
    void get(){
        cout<<"enter name of the student = ";
        getline(cin,nm);
        cout<<"enter student id = ";
        cin>>id;
        cout<<"enter marks of m1 = ";
        cin>>m1;
        cout<<"enter marks of m2 = ";
        cin>>m2;
    }

    void show(){
        cout<<"name of the student = "<<nm<<endl;
        cout<<"student id = "<<id<<endl;
        cout<<"m1 = "<<m1<<endl<<"m2 = "<<m2;
    }
};

class result : public student{
    public:
    int total,sports;
    float per;
    
    public:
    void cal(){
        get();
        cout<<"enter marks sports = ";
        cin>>sports;
        total = m1 + m2 + sports;
        per = (total/300.0)*100;
    }
    void show(){
        student :: show();
        cout<<endl<<"sports = "<<sports;
        cout<<endl<<"total marks = "<<total;
        cout<<endl<<"percentage = "<<per<<"%";
    }
};

int main(){
    result r;
    r.cal();
    r.show();
    return 0;
}
#include <iostream.h>
using namespace std;

class funtions
{
    int x, y, z;

public:
    void input()
    {
        cout << "enter x,y and z = ";
        cin >> x >> y >> z;
    }

    void output()
    {
        int a = x * y * z;
        cout << a;
        cout<<endl;
    }
};

int main()
{
    funtions f1,f2,f3;
    f1.input();
    cout<<endl;
    f2.input();
    cout<<endl;
    f3.input();
    cout<<endl;
    f1.output();
    f2.output();
    f3.output();
    return 0;
}
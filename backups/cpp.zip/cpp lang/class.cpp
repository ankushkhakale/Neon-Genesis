#include<iostream.h>
using namespace std;

class employee{
    private:
    int a,b,c;
    public:
    int d,e;
    void setData(int a1,int b1,int c1);
    void getData(){
        cout<<"a = "<<a<<endl;
        cout<<"b = "<<b<<endl;
        cout<<"c = "<<c<<endl;
        cout<<"d = "<<d<<endl;
        cout<<"e = "<<e;
    }
};

void employee::setData(int x,int y,int z){
    a = x;
    b = y;
    c = z;
}

int main(){
    employee mohit;
    mohit.d = 4;
    mohit.e = 5;
    mohit.setData(1,2,3);
    mohit.getData();
    return 0;
}
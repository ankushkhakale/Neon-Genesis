#include <iostream>
#include <list>
using namespace std;

class Product {
public:
    string name;
    float price;
    float rating;
};

int main() {
    list<Product> items;
    Product p;

    int n;
    cout << "Enter number of products: ";
    cin >> n;

    // input
    for (int i = 0; i < n; i++) {
        cout << "\nEnter product name: ";
        cin >> p.name;
        cout << "Enter price: ";
        cin >> p.price;
        cout << "Enter rating: ";
        cin >> p.rating;
        items.push_back(p);
    }

    // sort by price (ascending)
    items.sort([](Product a, Product b) {
        return a.price < b.price;
    });

    cout << "\nProducts sorted by ascending price:\n";
    for (auto &x : items)
        cout << x.name << " - " << x.price << " - " << x.rating << endl;

    // sort by rating (descending)
    items.sort([](Product a, Product b) {
        return a.rating > b.rating;
    });

    cout << "\nProducts sorted by descending rating:\n";
    for (auto &x : items)
        cout << x.name << " - " << x.price << " - " << x.rating << endl;

    return 0;
}

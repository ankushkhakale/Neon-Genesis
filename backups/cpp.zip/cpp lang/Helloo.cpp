#include<iostream>
#include<fstream>
#include<string>
using namespace std;

int main()
{
    ifstream iff;
    iff.open("secon.txt");
    ofstream of;
    of.open("secon.txt");
    cout<<"\nEnter text = ";
    string str;
    getline(cin,str);
    while(getline(iff,str))
    {
        cout<<str;
    }
    return 0;
}
#include<iostream.h>
using namespace std;

int main()
{
    int *ptr = new int;
    *ptr = 7;
    cout<<"ptr = "<<*(ptr);
    int a = 4;
    int *pptr = &a;
    *pptr = 5;
    cout<<"a = "<<*(pptr);
    delete ptr;
    return 0;
}
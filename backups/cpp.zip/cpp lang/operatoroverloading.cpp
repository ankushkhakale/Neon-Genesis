#include <iostream.h>
using namespace std;

class overloadop
{
    int m,n,a,b;
public:
    overloadop()
    {
        cout<<"enter the value of a = ";
        cin>>a;

        cout<<"enter the value of b = ";
        cin>>b;
        m = a;
        n = b;
    }

    void operator -()
    {
        m = m;
        n = n;
    }

    void show()
    {
        cout<<"\nM = "<<m<<"\t\t\t"<<"N = "<<n;
    }
};

int main()
{
    overloadop o;
    o.show();
    -o;
    o.show();
    return 0;
}
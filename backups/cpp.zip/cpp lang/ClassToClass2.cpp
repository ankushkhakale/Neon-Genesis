#include<iostream>
using namespace std;

class A
{   int real;
    public:
    A(int x):real(real)
    {
        this->real = 5;
    }
    operator int()
    {
        return real;
    }
};


class B
{
    public:
    int y;
    B(A objA)
    {
        y = objA;
    }
    void show()
    {
        cout<<"Y = "<<y;
    }
    
};
int main()
{
    int x = 5;
    A a = x;
    B b(a);
    b.show();
    return 0;
}
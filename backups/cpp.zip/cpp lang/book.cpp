#include <iostream>
#include <string>
using namespace std;
class Book {
private:
    int bookId;
    string bookName;
    string authorName;
    double rating;
public:
    // Constructor
    Book(int id, const string& name, const string& author, double rating) {
        bookId = id;
        bookName = name;
        authorName = author;
        this->rating = rating;
    }
    // Display book details
    void displayDetails() {
        cout << "Book ID: " << bookId << endl;
        cout << "Book Name: " << bookName << endl;
        cout << "Author Name: " << authorName << endl;
        cout << "Rating: " << rating << endl;
    }
};
int main() {
    // Create an instance of the Book class
    Book book1(1, "The Catcher in the Rye", "J.D. Salinger", 4.3);

    // Display book details
    book1.displayDetails();

    return 0;
}

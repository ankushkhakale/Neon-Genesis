#include<iostream>
using namespace std;

class UserProfile
{
    string name;
    int orders;
    bool active = true;
    public:
    UserProfile(){}
    UserProfile(string name = "", int orders = 0):name(name),orders(orders){}

    UserProfile operator++()
    {
        orders++;
    }

    UserProfile operator-()
    {
        active = false;
    }

    void show()
    {
        cout<<"Name = "<<name<<endl;
        cout<<"Orders Placed = "<<orders<<endl;
        cout<<"Account status = "<<(active?"Active":"Inactive")<<endl;
    }
};

int main()
{
    UserProfile uf("Kaneki", 5);
    uf.show();
    ++uf;
    -uf;
    uf.show(); 
    return 0;
}
#include <iostream>
#include <vector>
using namespace std;

int main() {
    vector<string> events;
    vector<int> hours;
    vector<float> ratings;

    int n;
    cout << "Enter number of events: ";
    cin >> n;

    for (int i = 0; i < n; i++) {
        string e; int h; float r;
        cout << "\nEvent " << i+1 << " name: "; cin >> e;
        cout << "Hours volunteered: "; cin >> h;
        cout << "Feedback rating: "; cin >> r;
        events.push_back(e);
        hours.push_back(h);
        ratings.push_back(r);
    }

    cout << "\n--- Volunteer Data ---\n";
    for (int i = 0; i < n; i++)
        cout << events[i] << " | Hours: " << hours[i]
             << " | Rating: " << ratings[i] << endl;
}

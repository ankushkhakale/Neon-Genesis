#include<iostream.h>
using namespace std;

//this code calculates cube and square for 10 numbers

class number{
    public:
    int cube,square;
    void cubee(int n){
        cube = n*n*n;
    }
    void squaree(int m){
        square = m*m;
    }
}sqandcu[10];

int main(){
    int arr[10];
    cout<<"get the cube of 10 numbers :";
    for(int i = 0;i < 10;i++){
        cout<<"\nenter a number here = ";
        cin>>arr[i];
        sqandcu[i].cubee(arr[i]);
        cout<<"cube of the number = "<<sqandcu[i].cube;
    }
    cout<<"get the square of 10 numbers :";
    for(int j = 0;j < 10;j++){
        cout<<"\nenter a number here = ";
        cin>>arr[j];
        sqandcu[j].squaree(arr[j]);
        cout<<"cube of the number = "<<sqandcu[j].square;
    }
    return 0;
}